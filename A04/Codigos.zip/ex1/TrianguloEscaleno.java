/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Diego
 */
public class TrianguloEscaleno extends Triangulo {
    
    public TrianguloEscaleno(Ponto pontoA, Ponto pontoB, Ponto pontoC){
        super(pontoA, pontoB, pontoC);
    }

    @Override
    public boolean validar() {
        // TODO
    }
    
}
