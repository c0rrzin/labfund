/**
 *
 * @author Diego
 */
public class TrianguloIsosceles extends Triangulo {
    
    public TrianguloIsosceles(Ponto pontoA, Ponto pontoB, Ponto pontoC){
        super(pontoA, pontoB, pontoC);
    }

    @Override
    public boolean validar() {
        // TODO
    }
    
}
