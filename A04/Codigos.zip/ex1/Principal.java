/**
 *
 * @author Diego
 */
public class Principal {

    public static void main(String[] args) {
        
        Poligono x1 = new Poligono(new Ponto[]{new Ponto(0,5), new Ponto(1,3), new Ponto(2,1)});  //N�o � tri�ngulo
        x1.imprime();
        
            
    }
}
