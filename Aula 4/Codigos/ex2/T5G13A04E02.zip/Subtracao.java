/**
 * Implementa a Operação de subtracao
 *
 */
public class Subtracao extends Operacoes {

  /**
   * Implementa a SUBTRACAO
   */
  public float calculaOperacao(float operando1, float operando2) {
    float resultado; //Variável que guardará o resultado.

    resultado= operando1 - operando2; //realiza a conta

    return resultado;
  }

}
