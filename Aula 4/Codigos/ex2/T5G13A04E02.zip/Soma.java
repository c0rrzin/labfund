/**
 * Implementa a Opera��o de soma
 *
 */
public class Soma extends Operacoes {

	/**
	 * Implementa a SOMA
	 */
	public float calculaOperacao(float operando1, float operando2) {
		float resultado; //Vari�vel que guardar� o resultado.
		
		resultado= operando1 + operando2; //realiza a conta
		
		return resultado;
	}

}
