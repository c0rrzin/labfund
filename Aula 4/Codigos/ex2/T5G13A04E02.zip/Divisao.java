/**
 * Implementa a Operação de divisao
 *
 */
public class Divisao extends Operacoes {

  /**
   * Implementa a DIVISAO
   */
  public float calculaOperacao(float operando1, float operando2) {
    float resultado; //Variável que guardará o resultado.

    resultado= operando1 / operando2; //realiza a conta

    return resultado;
  }

}
