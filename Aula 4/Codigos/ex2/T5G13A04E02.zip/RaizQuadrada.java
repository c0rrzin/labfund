/**
 * Implementa a Operação de raiz quadrada
 *
 */
public class RaizQuadrada extends Operacoes {

  /**
   * Implementa a raiz quadrada
   */
  public float calculaOperacao(float operando1, float operando2) {
    float resultado; //Variável que guardará o resultado.

    resultado= (float) Math.sqrt(operando1); //realiza a conta

    return resultado;
  }

}
